=============
AUTHORS
=============

* **Victor Dorneanu** (lead developer)
    + Twitter: `@victordorneanu <http://twitter.com/victordorneanu>`_
    + Web: `dornea.nu <http://dornea.nu>`_
    + Blog: `blog.dornea.nu <http://blog.dornea.nu>`_
    + GitHub: `github.com/dorneanu <http://github.com/dorneanu>`_
    + Xing: `xing.to/dorneanu <http://xing.to/dorneanu>`_

